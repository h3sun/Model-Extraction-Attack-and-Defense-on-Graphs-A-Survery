# Watermark by Random Graph

Watermarking Graph Neural Networks by Random Graphs

## Environment

- PyTorch
- PyTorch_geometric

## Run

run script to get all experiment results
```shell
python train.py
```