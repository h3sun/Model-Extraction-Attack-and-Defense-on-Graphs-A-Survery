# Model Extraction Attack

Model Extraction Attacks on Graph Neural Networks: Taxonomy and Realization

## Environment

- PyTorch
- DGL

## Run

you need to edit `run.py` to run specific attack type
```shell
python run.py
```
